package lab21;

public class Vector extends Punct{

	
	public Vector(Punct a, Punct b) {
	 super(a,b);
	}
	
	
	public static void vectorU(Punct a, Punct b) {
		
		System.out.println("Vectorul u="+ (b.getX()-a.getX() +"*i"+ "+" +(b.getY()-a.getY())+"*j"));
	}
	
	public static void vectorV(Punct a, Punct b) {
		
		System.out.println("Vectorul v="+ (b.getX()-a.getX() +"*i"+ "+" +(b.getY()-a.getY())+"*j"));
	}
	
}
