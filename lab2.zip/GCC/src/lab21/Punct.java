package lab21;

public class Punct {
	private double x;
	private double y;
	
	public Punct(double x, double y) {
		this.x=x;
		this.y=y;
	}

	public Punct(Punct a, Punct b) {
		// TODO Auto-generated constructor stub
	}

	public double getX() {
		return x;
	}

	public void setX(double x) {
		this.x = x;
	}

	public double getY() {
		return y;
	}

	public void setY(double y) {
		this.y = y;
	}
	
	public double distanta(Punct a, Punct b) {
		return Math.sqrt((b.getX()-a.getX())*(b.getX()-a.getX())+((b.getY()-a.getY())*(b.getY()-a.getY())));
	}
	
	public double panta(Punct a, Punct b)
	{ return (b.getY()-a.getY())/(b.getX()-a.getX());}
	
	

}
