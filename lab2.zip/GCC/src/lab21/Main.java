package lab21;

import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	

	Punct a=new Punct(1,1);
	Punct b=new Punct(3,1);
	Punct c=new Punct(4,2);
	Punct d= new Punct(2,2);
	Vector v=new Vector(a,b);
	Vector u=new Vector(c,d);
	
	
	 System.out.println("Aria:"+ aria(a,b,c,d));
	 verifParalelogram(a,b,c,d);
	 vectori(a,b,c,d,u,v);
	 System.out.print("Produsul scalar al celor doi vectori este:");
	 System.out.println(ProdusulScalar(a,b,c,d));
	 System.out.print("Lungimea vectorului U este:");
	 System.out.println(lungimeVectorU(a,b));
	 System.out.print("Lungimea vectorului V este:");
	 System.out.println(lungimeVectorV(c,d));
	 VerificareDreptunghi(a,b,c,d);
	 VerificarePatrat(a,b,c,d);
	 VerificareRomb(a,b,c,d);
	 PatrulaterInscriptibil(a,b,c,d);
	
}

	public static double aria(Punct a, Punct b, Punct c, Punct d) {
		 double p=(a.distanta(a, b)+b.distanta(b, d)+d.distanta(a, d))/2;
		 double p1=(d.distanta(d, b)+b.distanta(b, c)+c.distanta(c, d))/2;

		return  Math.sqrt((p*(p-a.distanta(a, b))*(p-b.distanta(b, d))*(p-d.distanta(a, d))))+  (Math.sqrt(p1*(p1-d.distanta(d, b))*(p1-b.distanta(b, c))*(p1-c.distanta(c, d))));
	}
	
	public static void verifParalelogram(Punct a, Punct b, Punct c, Punct d) {
		
		if(a.panta(a, b)==c.panta(c,d)) System.out.println("Verificare: Patrulaterul este paralelogram");
		else System.out.println("Verificare: Patrulaterul nu este paralelogram");
		
	}
	public static void vectori(Punct a, Punct b, Punct c, Punct d, Vector u, Vector v) {
		u.vectorU(a,b);
		v.vectorV(c, d);}
	
	public static double ProdusulScalar(Punct a, Punct b, Punct c, Punct d) {
		int produs=(int)((b.getX()-a.getX())*(d.getX()-c.getX())+(b.getY()-a.getY())*(d.getY()-c.getY()));
		return produs;
	
	}
	
	
	public static double lungimeVectorU(Punct a, Punct b) {
		return Math.sqrt((b.getX()-a.getX())*(b.getX()-a.getX())+(b.getY()-a.getY())*(b.getY()-a.getY()));
	}
	
	public static double lungimeVectorV( Punct c, Punct d) {
		return Math.sqrt((d.getX()-c.getX())*(d.getX()-c.getX())+(d.getY()-c.getY())*(d.getY()-c.getY()));
	}
	
	public static void VerificareDreptunghi(Punct a, Punct b, Punct c, Punct d) {
		int raport=(int)(ProdusulScalar(a,b,c,d));
	    int lungU=(int)(lungimeVectorU(a,b));
	    int lungV=(int)(lungimeVectorV(c,d));
	    int raport1=(int)(raport/(lungU*lungV));
		 if(Math.acos(raport1)==Math.PI) System.out.println("Verificare: Patrulaterul este dreptunghi");
		 else  System.out.println("Verificare: Patrulaterul nu este dreptunghi");
	}
	
	public static void VerificarePatrat(Punct a, Punct b, Punct c, Punct d) {
		int raport=(int)(ProdusulScalar(a,b,c,d));
	    int lungU=(int)(lungimeVectorU(a,b));
	    int lungV=(int)(lungimeVectorV(c,d));
	    int raport1=(int)(raport/(lungU*lungV));
		 if(Math.acos(raport1)==Math.PI && (b.getX()-a.getX())*(b.getX()-a.getX())+(b.getY()-a.getY())*(b.getY()-a.getY())==(d.getX()-c.getX())*(d.getX()-c.getX())+(d.getY()-c.getY())*(d.getY()-c.getY())) System.out.println("Verificare: Patrulaterul este patrat");
		 else  System.out.println("Verificare: Patrulaterul nu este patrat");
	}
	

	
	public static void VerificareRomb(Punct a, Punct b, Punct c, Punct d) {
		if(a.panta(a, b)==c.panta(c,d)&&(b.getX()-a.getX())*(b.getX()-a.getX())+(b.getY()-a.getY())*(b.getY()-a.getY())==(d.getX()-c.getX())*(d.getX()-c.getX())+(d.getY()-c.getY())*(d.getY()-c.getY())) System.out.println("Verificare: Patrulaterul este romb");
		else System.out.println("Verificare: Patrulaterul nu este romb");
	}
	
	public static void PatrulaterInscriptibil(Punct a, Punct b, Punct c, Punct d) {
		int raport=(int)(ProdusulScalar(a,b,a,d));
	    int lungU=(int)(lungimeVectorU(a,b));
	    int lungV=(int)(lungimeVectorV(a,d));
	    int raport1=(int)(Math.acos(raport/(lungU*lungV)));
	    int raport2=(int)(ProdusulScalar(b,c,c,d));
	    int lungU1=(int)(lungimeVectorU(b,c));
	    int lungV1=(int)(lungimeVectorV(c,d));
	    int raport3=(int)(Math.acos(raport/(lungU*lungV)));
	    
		
	    int raport4=(int)(ProdusulScalar(d,a,d,c));
	    int lungU2=(int)(lungimeVectorU(d,a));
	    int lungV2=(int)(lungimeVectorV(d,c));
	    int raport5=(int)(Math.acos(raport/(lungU*lungV)));
	    
	    int raport6=(int)(ProdusulScalar(a,b,b,c));
	    int lungU3=(int)(lungimeVectorU(a,b));
	    int lungV3=(int)(lungimeVectorV(b,c));
	    int raport7=(int)(Math.acos(raport/(lungU*lungV)));
		int sum=(int) (Math.acos(raport1)+Math.acos(raport3));
	    int sum1=(int) (Math.acos(raport5)+Math.acos(raport7));
	    
	    if(sum1==sum&&sum==(int)Math.PI)
	     System.out.println("Patrulaterul  este inscriptibil");
	    else 
	    	System.out.println("Patrulaterul nu este inscriptibil");
	}
	

}
	




